import React from 'react';
import { StackNavigator } from '@nativescript/core';
import { QRScanner } from '../screens/QRScanner';
import { ContactsPermission } from '../screens/ContactsPermission';
import { PairingSuccess } from '../screens/PairingSuccess';

export function MainStack() {
  return (
    <StackNavigator
      initialRoute="qrScanner"
      screenOptions={{
        headerStyle: {
          backgroundColor: '#004D56'
        },
        headerTintColor: '#fff'
      }}
    >
      <StackNavigator.Screen
        name="qrScanner"
        component={QRScanner}
        options={{ title: 'Scan QR Code' }}
      />
      <StackNavigator.Screen
        name="contactsPermission"
        component={ContactsPermission}
        options={{ title: 'Contacts Access' }}
      />
      <StackNavigator.Screen
        name="pairingSuccess"
        component={PairingSuccess}
        options={{ title: 'Setup Complete' }}
      />
    </StackNavigator>
  );
}