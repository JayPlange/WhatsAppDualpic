import { io, Socket } from 'socket.io-client';

const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || 'http://localhost:3000';
const RECONNECTION_ATTEMPTS = 5;
const INITIAL_RECONNECTION_DELAY = 1000;
const MAX_RECONNECTION_DELAY = 30000; // Maximum delay of 30 seconds
const SOCKET_TIMEOUT = 120000; // Increased to 120 seconds

class SocketService {
  private socket: Socket | null = null;
  private reconnectAttempts = 0;
  private isConnecting = false;
  private currentReconnectionDelay = INITIAL_RECONNECTION_DELAY;

  private calculateNextDelay(): number {
    // Exponential backoff with jitter
    const jitter = Math.random() * 100;
    this.currentReconnectionDelay = Math.min(
      this.currentReconnectionDelay * 2,
      MAX_RECONNECTION_DELAY
    );
    return this.currentReconnectionDelay + jitter;
  }

  private resetReconnectionDelay() {
    this.currentReconnectionDelay = INITIAL_RECONNECTION_DELAY;
  }

  connect() {
    if (this.socket?.connected) {
      console.log('Socket already connected');
      return;
    }

    if (this.isConnecting) {
      console.log('Socket connection already in progress');
      return;
    }

    try {
      console.log(`Attempting to connect to ${SOCKET_URL}`);
      this.isConnecting = true;

      this.socket = io(SOCKET_URL, {
        autoConnect: false,
        reconnection: true,
        reconnectionAttempts: RECONNECTION_ATTEMPTS,
        reconnectionDelay: this.currentReconnectionDelay,
        timeout: SOCKET_TIMEOUT,
        transports: ['websocket', 'polling'],
        path: '/ws',
        forceNew: true,
      });

      this.setupListeners();
      this.socket.connect();
    } catch (error) {
      console.error('Failed to initialize socket connection:', error);
      this.isConnecting = false;
      this.handleConnectionFailure();
    }
  }

  private handleConnectionFailure() {
    if (this.socket) {
      this.socket.close();
      this.socket = null;
    }
    this.isConnecting = false;
    this.reconnectAttempts = 0;
    this.resetReconnectionDelay();
    console.warn(`Connection failed to ${SOCKET_URL}. Please check if the server is running and the SOCKET_URL is correct.`);
  }

  private setupListeners() {
    if (!this.socket) return;

    this.socket.on('connect', () => {
      console.log('Socket connected successfully');
      this.isConnecting = false;
      this.reconnectAttempts = 0;
      this.resetReconnectionDelay();
    });

    this.socket.on('connect_error', (error) => {
      console.error('Socket connection error:', error.message);
      this.reconnectAttempts++;
      
      if (this.reconnectAttempts >= RECONNECTION_ATTEMPTS) {
        console.error(`Max reconnection attempts (${RECONNECTION_ATTEMPTS}) reached`);
        this.handleConnectionFailure();
      } else {
        const nextDelay = this.calculateNextDelay();
        console.log(`Next reconnection attempt in ${nextDelay}ms`);
      }
    });

    this.socket.on('disconnect', (reason) => {
      console.log('Socket disconnected:', reason);
      this.isConnecting = false;
      
      if (reason === 'io server disconnect') {
        this.handleConnectionFailure();
      }
    });

    this.socket.on('error', (error) => {
      console.error('Socket error:', error);
      this.isConnecting = false;
    });

    this.socket.on('reconnect', (attemptNumber) => {
      console.log(`Socket reconnected after ${attemptNumber} attempts`);
      this.isConnecting = false;
      this.resetReconnectionDelay();
    });

    this.socket.on('reconnect_attempt', (attemptNumber) => {
      console.log(`Socket reconnection attempt ${attemptNumber}`);
    });

    this.socket.on('reconnect_error', (error) => {
      console.error('Socket reconnection error:', error);
    });

    this.socket.on('reconnect_failed', () => {
      console.error('Socket reconnection failed');
      this.handleConnectionFailure();
    });
  }

  emit(event: string, data: any) {
    if (!this.socket?.connected) {
      console.warn('Socket not connected, attempting to connect before emitting');
      this.connect();
      
      // Queue the emit for when we're connected
      this.socket?.once('connect', () => {
        console.log(`Emitting queued event: ${event}`);
        this.socket?.emit(event, data);
      });
      return;
    }

    try {
      console.log(`Emitting event: ${event}`, data);
      this.socket.emit(event, data);
    } catch (error) {
      console.error(`Error emitting event ${event}:`, error);
    }
  }

  on(event: string, callback: (data: any) => void) {
    if (!this.socket?.connected && !this.isConnecting) {
      this.connect();
    }

    this.socket?.on(event, (data) => {
      try {
        console.log(`Received event: ${event}`, data);
        callback(data);
      } catch (error) {
        console.error(`Error in event handler for ${event}:`, error);
      }
    });
  }

  off(event: string, callback?: (data: any) => void) {
    this.socket?.off(event, callback);
  }

  disconnect() {
    try {
      if (this.socket?.connected) {
        console.log('Disconnecting socket');
        this.socket.close();
      }
      this.socket = null;
      this.isConnecting = false;
      this.resetReconnectionDelay();
    } catch (error) {
      console.error('Error disconnecting socket:', error);
    }
  }

  isConnected(): boolean {
    return this.socket?.connected || false;
  }
}

export const socket = new SocketService();