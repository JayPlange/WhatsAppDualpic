import { socket } from './socket';

export interface Contact {
  id: string;
  name: string;
  phone?: string;
}

export async function syncWhatsAppContacts(): Promise<Contact[]> {
  try {
    const chatList = document.querySelector('[data-testid="chat-list"]');
    if (!chatList) {
      throw new Error('WhatsApp chat list not found');
    }

    const contacts = Array.from(
      chatList.querySelectorAll('[data-testid="cell-frame-title"]')
    ).map((element, index) => ({
      id: `contact-${index}`,
      name: element.textContent?.trim() || '',
      phone: element.getAttribute('data-phone') || undefined
    }));

    // Emit contacts through WebSocket if connected
    if (socket.connected) {
      socket.emit('sync-contacts', { contacts });
    }

    return contacts;
  } catch (error) {
    console.error('Failed to sync WhatsApp contacts:', error);
    return [];
  }
}

export function setupContactSync(): void {
  const observer = new MutationObserver(() => {
    const chatList = document.querySelector('[data-testid="chat-list"]');
    if (chatList) {
      observer.disconnect();
      syncWhatsAppContacts().catch(console.error);
    }
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
}