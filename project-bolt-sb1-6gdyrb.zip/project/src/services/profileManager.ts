// Lightweight service for managing profiles in content script
export function setupProfileManager() {
  // Initialize styles
  const style = document.createElement('style');
  style.textContent = `
    .wapp-dual-indicator {
      position: fixed;
      bottom: 20px;
      right: 20px;
      background: #00F9B0;
      color: #004D56;
      padding: 8px 16px;
      border-radius: 20px;
      font-size: 12px;
      z-index: 9999;
      box-shadow: 0 2px 8px rgba(0, 77, 86, 0.2);
      display: flex;
      align-items: center;
      gap: 8px;
      animation: slideIn 0.3s ease-out;
    }

    @keyframes slideIn {
      from {
        transform: translateY(20px);
        opacity: 0;
      }
      to {
        transform: translateY(0);
        opacity: 1;
      }
    }
  `;
  document.head.appendChild(style);
}