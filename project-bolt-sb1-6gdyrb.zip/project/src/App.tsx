import React, { useState, useCallback, useEffect } from 'react';
import { Upload, Users, UserCheck, Save, PartyPopper, Smartphone } from 'lucide-react';
import { ProfileUploader } from './components/ProfileUploader';
import { VIPSelector } from './components/VIPSelector';
import { SuccessAnimation } from './components/SuccessAnimation';
import { QRPairingModal } from './components/QRPairingModal';
import { socket } from './services/socket';
import { chromeAPI } from './utils/chrome';

export default function App() {
  const [photo1, setPhoto1] = useState<string | null>(null);
  const [photo2, setPhoto2] = useState<string | null>(null);
  const [visibility1, setVisibility1] = useState('everyone');
  const [visibility2, setVisibility2] = useState('everyone');
  const [selectedVIPs1, setSelectedVIPs1] = useState<string[]>([]);
  const [selectedVIPs2, setSelectedVIPs2] = useState<string[]>([]);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showVIPSelector, setShowVIPSelector] = useState(false);
  const [activePhotoNum, setActivePhotoNum] = useState<1 | 2>(1);
  const [showQRPairing, setShowQRPairing] = useState(false);
  const [isPaired, setIsPaired] = useState(false);
  const [contacts, setContacts] = useState<any[]>([]);

  useEffect(() => {
    // Check if device is already paired
    const checkPairingStatus = async () => {
      try {
        const status = await chromeAPI.storage.local.get('isPaired');
        if (status.isPaired) {
          setIsPaired(true);
          // Also load contacts if available
          const savedContacts = await chromeAPI.storage.local.get('contacts');
          if (savedContacts.contacts) {
            setContacts(savedContacts.contacts);
          }
        }
      } catch (error) {
        console.error('Failed to check pairing status:', error);
      }
    };

    checkPairingStatus();

    // Setup socket listeners
    socket.on('contacts-synced', async (data) => {
      setContacts(data.contacts);
      setIsPaired(true);
      try {
        await chromeAPI.storage.local.set({ 
          isPaired: true,
          contacts: data.contacts 
        });
      } catch (error) {
        console.error('Failed to save pairing status:', error);
      }
      setShowQRPairing(false);
    });

    return () => {
      socket.off('contacts-synced');
    };
  }, []);

  const handleSave = useCallback(() => {
    const profiles = {
      photo1,
      photo2,
      visibility1,
      visibility2,
      vips1: selectedVIPs1,
      vips2: selectedVIPs2
    };

    chromeAPI.runtime.sendMessage({
      type: 'PROFILES_UPDATED',
      data: profiles
    });

    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  }, [photo1, photo2, visibility1, visibility2, selectedVIPs1, selectedVIPs2]);

  const handleVisibilityChange = (photoNum: 1 | 2, value: string) => {
    if (value === 'vip' && isPaired) {
      setActivePhotoNum(photoNum);
      setShowVIPSelector(true);
    } else if (photoNum === 1) {
      setVisibility1(value);
    } else {
      setVisibility2(value);
    }
  };

  const handlePairDevice = () => {
    setShowQRPairing(true);
  };

  return (
    <div className="w-[400px] min-h-[600px] bg-gradient-custom">
      <header className="p-6 text-white">
        <div className="flex items-center gap-3 mb-2 floating">
          <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
            <Users className="w-6 h-6 text-[#004D56]" />
          </div>
          <h1 className="text-2xl font-bold">WhatsApp DualPic</h1>
        </div>
        <p className="text-sm opacity-90">Your Shortcut to Privacy</p>
      </header>

      <main className="p-6 space-y-6">
        {!isPaired && (
          <div className="bg-white bg-opacity-90 backdrop-blur-lg rounded-xl p-6 text-center">
            <Smartphone className="w-12 h-12 text-[#00F9B0] mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-[#004D56] mb-2">
              Pair Your Device
            </h2>
            <p className="text-gray-600 mb-4">
              Connect your phone to enable selective visibility and contact sync
            </p>
            <button
              onClick={handlePairDevice}
              className="w-full py-3.5 px-4 bg-[#004D56] hover:bg-[#00F9B0] transition-all duration-300 text-white rounded-xl font-semibold flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
            >
              <Smartphone className="w-5 h-5" />
              Pair Device
            </button>
          </div>
        )}

        <div className="space-y-4">
          <ProfileUploader
            title="Primary Profile"
            photo={photo1}
            setPhoto={setPhoto1}
            visibility={visibility1}
            onVisibilityChange={(value) => handleVisibilityChange(1, value)}
          />

          <ProfileUploader
            title="Secondary Profile"
            photo={photo2}
            setPhoto={setPhoto2}
            visibility={visibility2}
            onVisibilityChange={(value) => handleVisibilityChange(2, value)}
          />
        </div>

        <button
          onClick={handleSave}
          className="w-full py-3.5 px-4 bg-white hover:bg-[#00F9B0] transition-all duration-300 text-[#004D56] rounded-xl font-semibold flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
        >
          <Save className="w-5 h-5" />
          Update Profiles
        </button>

        {showSuccess && <SuccessAnimation />}

        {showVIPSelector && (
          <VIPSelector
            contacts={contacts}
            onClose={() => setShowVIPSelector(false)}
            onSave={(selected) => {
              if (activePhotoNum === 1) {
                setSelectedVIPs1(selected);
                setVisibility1('vip');
              } else {
                setSelectedVIPs2(selected);
                setVisibility2('vip');
              }
              setShowVIPSelector(false);
            }}
          />
        )}

        {showQRPairing && (
          <QRPairingModal
            onClose={() => setShowQRPairing(false)}
            onPaired={() => setIsPaired(true)}
          />
        )}
      </main>
    </div>
  );
}