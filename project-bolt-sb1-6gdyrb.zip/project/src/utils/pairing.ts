import { nanoid } from 'nanoid';

/**
 * Generates a unique 8-character pairing code
 */
export function generatePairingCode(): string {
  return nanoid(8);
}