// Type definitions for Chrome API
interface ChromeAPI {
  runtime: {
    sendMessage: (message: any) => Promise<any>;
  };
  storage: {
    local: {
      get: <T = any>(key: string | string[]) => Promise<T>;
      set: (data: Record<string, any>) => Promise<void>;
    };
  };
}

// Mock implementation for development
const mockChromeAPI: ChromeAPI = {
  runtime: {
    sendMessage: async (message: any) => {
      console.log('Mock chrome.runtime.sendMessage:', message);
      return { success: true };
    }
  },
  storage: {
    local: {
      get: async <T>(key: string | string[]): Promise<T> => {
        const storageData = localStorage.getItem('mockChromeStorage');
        if (!storageData) return {} as T;
        
        const data = JSON.parse(storageData);
        if (typeof key === 'string') {
          return { [key]: data[key] } as T;
        }
        
        const result: Record<string, any> = {};
        key.forEach(k => {
          if (k in data) result[k] = data[k];
        });
        return result as T;
      },
      set: async (data: Record<string, any>) => {
        const storageData = localStorage.getItem('mockChromeStorage');
        const currentData = storageData ? JSON.parse(storageData) : {};
        localStorage.setItem('mockChromeStorage', JSON.stringify({
          ...currentData,
          ...data
        }));
      }
    }
  }
};

// Determine if we're in a Chrome extension environment
const isExtensionEnvironment = typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage;

// Export the appropriate API
export const chromeAPI: ChromeAPI = isExtensionEnvironment 
  ? {
      runtime: {
        sendMessage: (message: any) => new Promise((resolve) => {
          chrome.runtime.sendMessage(message, resolve);
        })
      },
      storage: {
        local: {
          get: (key: string | string[]) => new Promise((resolve) => {
            chrome.storage.local.get(key, resolve);
          }),
          set: (data: Record<string, any>) => new Promise((resolve) => {
            chrome.storage.local.set(data, resolve);
          })
        }
      }
    } 
  : mockChromeAPI;