import { useState, useEffect, useCallback } from 'react';
import { chromeAPI } from '../utils/chrome';
import { Profile } from '../types';

const defaultProfile: Profile = {
  photo1: null,
  photo2: null,
  visibility1: 'everyone',
  visibility2: 'everyone',
  vips1: [],
  vips2: []
};

export function useProfiles() {
  const [profiles, setProfiles] = useState<Profile>(defaultProfile);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    const loadProfiles = async () => {
      try {
        const data = await chromeAPI.storage.local.get('profiles');
        setLoading(false);
        if (data.profiles) {
          setProfiles(data.profiles);
        }
      } catch (err) {
        setError(err instanceof Error ? err : new Error('Failed to load profiles'));
        setLoading(false);
      }
    };

    loadProfiles();
  }, []);

  const updateProfiles = useCallback(async (newProfiles: Partial<Profile>) => {
    try {
      const updatedProfiles = { ...profiles, ...newProfiles };
      await chromeAPI.storage.local.set({ profiles: updatedProfiles });
      await chromeAPI.runtime.sendMessage({
        type: 'PROFILES_UPDATED',
        data: updatedProfiles
      });
      setProfiles(updatedProfiles);
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to update profiles'));
    }
  }, [profiles]);

  return { profiles, loading, error, updateProfiles };
}