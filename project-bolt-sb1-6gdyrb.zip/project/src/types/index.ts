export interface Contact {
  id: string;
  name: string;
  phone?: string;
}

export interface Profile {
  photo1: string | null;
  photo2: string | null;
  visibility1: 'everyone' | 'vip';
  visibility2: 'everyone' | 'vip';
  vips1: string[];
  vips2: string[];
}

export interface PairingStatus {
  isPaired: boolean;
  contacts?: Contact[];
}