// Content script - Lightweight and independent from React
import { setupProfileManager } from './services/profileManager';
import { setupContactSync } from './services/contactSync';

// Initialize core functionality
setupProfileManager();
setupContactSync();

// Listen for messages from extension
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'SYNC_WHATSAPP_CONTACTS':
      getWhatsAppContacts().then(sendResponse);
      return true;

    case 'PROFILES_UPDATED':
      handleProfileUpdate(message.data);
      break;
  }
});

// Get WhatsApp contacts
async function getWhatsAppContacts(): Promise<{ success: boolean; contacts?: string[]; error?: string }> {
  try {
    const chatList = await waitForElement('[data-testid="chat-list"]');
    const contacts = Array.from(
      chatList.querySelectorAll('[data-testid="cell-frame-title"]')
    ).map(el => el.textContent?.trim()).filter(Boolean) as string[];

    return { success: true, contacts };
  } catch (error) {
    console.error('Failed to get WhatsApp contacts:', error);
    return { success: false, error: 'WhatsApp Web not ready' };
  }
}

// Handle profile updates
function handleProfileUpdate(profiles: any) {
  const indicator = createUpdateIndicator();
  document.body.appendChild(indicator);
  setTimeout(() => indicator.remove(), 3000);

  updateProfilePicture(profiles);
}

// Helper: Wait for element
function waitForElement(selector: string): Promise<Element> {
  return new Promise((resolve) => {
    if (document.querySelector(selector)) {
      return resolve(document.querySelector(selector)!);
    }

    const observer = new MutationObserver(() => {
      const element = document.querySelector(selector);
      if (element) {
        observer.disconnect();
        resolve(element);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  });
}

// Helper: Create update indicator
function createUpdateIndicator(): HTMLDivElement {
  const indicator = document.createElement('div');
  indicator.className = 'wapp-dual-indicator';
  indicator.innerHTML = `
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M20 6L9 17l-5-5"/>
    </svg>
    Profiles Updated
  `;
  return indicator;
}

// Helper: Update profile picture
function updateProfilePicture(profiles: any) {
  const contactName = document.querySelector(
    '[data-testid="conversation-info-header-chat-title"]'
  )?.textContent;

  if (!contactName) return;

  const isVIP1 = profiles.vips1.includes(contactName);
  const isVIP2 = profiles.vips2.includes(contactName);
  const profilePic = getVisibleProfile(profiles, isVIP1, isVIP2);

  if (profilePic) {
    const profileElement = document.querySelector('[data-testid="default-user"] img');
    if (profileElement) {
      profileElement.setAttribute('src', profilePic);
    }
  }
}

// Helper: Get visible profile
function getVisibleProfile(profiles: any, isVIP1: boolean, isVIP2: boolean): string | null {
  const { photo1, photo2, visibility1, visibility2 } = profiles;

  if (visibility1 === 'everyone' || (visibility1 === 'vip' && isVIP1)) {
    return photo1;
  }

  if (visibility2 === 'everyone' || (visibility2 === 'vip' && isVIP2)) {
    return photo2;
  }

  return null;
}