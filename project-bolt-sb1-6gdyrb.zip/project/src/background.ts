import { socket } from './services/socket';

// Handle extension installation
chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension installed');
  
  // Initialize storage with default values
  chrome.storage.local.set({
    profiles: {
      timestamp: Date.now(),
      photo1: null,
      photo2: null,
      visibility1: 'everyone',
      visibility2: 'everyone',
      vips1: [],
      vips2: []
    }
  });
});

// Listen for messages from content script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'PROFILE_UPDATE':
      handleProfileUpdate(message.data, sendResponse);
      return true; // Keep channel open for async response
    case 'GET_PROFILES':
      handleGetProfiles(sendResponse);
      return true; // Keep channel open for async response
  }
});

// Handle profile updates
async function handleProfileUpdate(data: any, sendResponse: (response: any) => void) {
  try {
    // Store profiles in chrome.storage
    await chrome.storage.local.set({
      profiles: {
        timestamp: Date.now(),
        ...data
      }
    });

    // Notify content script to update UI
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab.id) {
      chrome.tabs.sendMessage(tab.id, {
        type: 'PROFILES_UPDATED',
        data
      });
    }

    sendResponse({ success: true });
  } catch (error) {
    console.error('Profile update failed:', error);
    sendResponse({ success: false, error: 'Failed to update profiles' });
  }
}

// Handle profile retrieval
async function handleGetProfiles(sendResponse: (response: any) => void) {
  try {
    const data = await chrome.storage.local.get('profiles');
    sendResponse({ success: true, data: data.profiles });
  } catch (error) {
    console.error('Failed to retrieve profiles:', error);
    sendResponse({ success: false, error: 'Failed to retrieve profiles' });
  }
}