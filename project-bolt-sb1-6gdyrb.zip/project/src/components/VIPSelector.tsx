import React, { useState, useEffect } from 'react';
import { X, Search, Check, Users } from 'lucide-react';

interface Contact {
  id: string;
  name: string;
  phone?: string;
}

interface VIPSelectorProps {
  contacts: Contact[];
  onClose: () => void;
  onSave: (selected: string[]) => void;
  initialSelected?: string[];
}

export function VIPSelector({ contacts, onClose, onSave, initialSelected = [] }: VIPSelectorProps) {
  const [selected, setSelected] = useState<string[]>(initialSelected);
  const [search, setSearch] = useState('');
  const [filteredContacts, setFilteredContacts] = useState<Contact[]>(contacts);

  useEffect(() => {
    const filtered = contacts.filter((contact) =>
      contact.name.toLowerCase().includes(search.toLowerCase()) ||
      contact.phone?.includes(search)
    );
    setFilteredContacts(filtered);
  }, [contacts, search]);

  const handleToggle = (id: string) => {
    setSelected((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-[9999]">
      <div className="bg-white rounded-xl w-full max-w-md max-h-[80vh] flex flex-col transform transition-all duration-300 ease-in-out">
        <div className="p-4 border-b flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-[#00F9B0]" />
            <h3 className="text-lg font-semibold text-[#004D56]">Select Contacts</h3>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-[#004D56]" />
          </button>
        </div>

        <div className="p-4 border-b">
          <div className="relative">
            <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search contacts..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00F9B0] focus:border-transparent transition-all"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {filteredContacts.length === 0 ? (
            <div className="p-4 text-center text-gray-500">
              No contacts found
            </div>
          ) : (
            filteredContacts.map((contact) => (
              <label
                key={contact.id}
                className="flex items-center p-4 hover:bg-gray-50 cursor-pointer"
              >
                <input
                  type="checkbox"
                  checked={selected.includes(contact.id)}
                  onChange={() => handleToggle(contact.id)}
                  className="hidden"
                />
                <div className="flex-1">
                  <p className="font-medium text-[#004D56]">{contact.name}</p>
                  {contact.phone && (
                    <p className="text-sm text-gray-500">{contact.phone}</p>
                  )}
                </div>
                <div
                  className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all duration-300 ${
                    selected.includes(contact.id)
                      ? 'bg-[#00F9B0] border-[#00F9B0]'
                      : 'border-gray-300'
                  }`}
                >
                  {selected.includes(contact.id) && (
                    <Check className="w-4 h-4 text-white" />
                  )}
                </div>
              </label>
            ))
          )}
        </div>

        <div className="p-4 border-t bg-gray-50 rounded-b-xl">
          <button
            onClick={() => onSave(selected)}
            className="w-full py-3 bg-[#004D56] hover:bg-[#00F9B0] text-white rounded-lg font-semibold transition-all duration-300 transform hover:-translate-y-1 hover:shadow-lg flex items-center justify-center gap-2"
          >
            <Users className="w-4 h-4" />
            Save Selection ({selected.length} selected)
          </button>
        </div>
      </div>
    </div>
  );
}