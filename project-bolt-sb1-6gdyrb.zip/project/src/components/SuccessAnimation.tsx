import React, { useEffect } from 'react';
import { PartyPopper } from 'lucide-react';

export function SuccessAnimation() {
  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js';
    document.body.appendChild(script);

    script.onload = () => {
      // @ts-ignore
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#00F9B0', '#004D56', '#7FFFD4']
      });
    };

    return () => {
      document.body.removeChild(script);
    };
  }, []);

  return (
    <div className="fixed inset-0 flex items-center justify-center pointer-events-none z-50">
      <div className="bg-white bg-opacity-95 backdrop-blur-sm rounded-xl p-6 shadow-xl pulse">
        <PartyPopper className="w-12 h-12 text-primary mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-center text-primary-dark">
          Profiles Updated!
        </h2>
      </div>
    </div>
  );
}