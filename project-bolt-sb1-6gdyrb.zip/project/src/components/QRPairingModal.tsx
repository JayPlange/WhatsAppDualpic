import React, { useState, useEffect } from 'react';
import QRCode from 'react-qr-code';
import { X, Smartphone, Check, Loader } from 'lucide-react';
import { socket } from '../services/socket';
import { generatePairingCode } from '../utils/pairing';

interface QRPairingModalProps {
  onClose: () => void;
  onPaired: () => void;
}

export function QRPairingModal({ onClose, onPaired }: QRPairingModalProps) {
  const [pairingStatus, setPairingStatus] = useState<'connecting' | 'waiting' | 'paired' | 'error'>('connecting');
  const [pairingCode, setPairingCode] = useState<string>('');
  const [error, setError] = useState<string>('');

  useEffect(() => {
    const setupPairing = () => {
      try {
        // Generate a unique pairing code
        const code = generatePairingCode();
        setPairingCode(code);

        // Connect to WebSocket if not connected
        if (!socket.connected) {
          socket.connect();
        }

        // Listen for pairing events
        socket.on('connect', () => {
          setPairingStatus('waiting');
          socket.emit('pair-request', { code });
        });

        socket.on('connect_error', () => {
          setPairingStatus('error');
          setError('Failed to connect to server');
        });

        socket.on('pairing-successful', () => {
          setPairingStatus('paired');
          setTimeout(() => {
            onPaired();
            onClose();
          }, 1500);
        });

        setPairingStatus('waiting');
      } catch (error) {
        console.error('Pairing setup failed:', error);
        setPairingStatus('error');
        setError('Failed to generate pairing code');
      }
    };

    setupPairing();

    return () => {
      socket.off('connect');
      socket.off('connect_error');
      socket.off('pairing-successful');
    };
  }, [onPaired, onClose]);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl w-full max-w-md flex flex-col slide-in">
        <div className="p-6 border-b flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Smartphone className="w-6 h-6 text-primary" />
            <h3 className="text-xl font-semibold text-primary-dark">Pair Your Device</h3>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-primary-dark" />
          </button>
        </div>

        <div className="p-8 flex flex-col items-center text-center">
          {pairingStatus === 'connecting' && (
            <div className="flex flex-col items-center gap-4">
              <Loader className="w-8 h-8 text-primary animate-spin" />
              <p className="text-primary-dark font-medium">Connecting to server...</p>
            </div>
          )}

          {pairingStatus === 'waiting' && pairingCode && (
            <>
              <div className="mb-6 p-4 bg-white rounded-xl shadow-lg">
                <QRCode
                  value={pairingCode}
                  size={200}
                  style={{ height: "auto", maxWidth: "100%", width: "100%" }}
                  viewBox="0 0 256 256"
                />
              </div>

              <div className="space-y-2 mb-6">
                <p className="text-lg font-semibold text-primary-dark">
                  Scan with WhatsApp DualPic
                </p>
                <p className="text-sm text-gray-600">
                  Open the WhatsApp DualPic mobile app and scan this QR code to sync your contacts
                </p>
              </div>

              <div className="flex items-center gap-2">
                <Loader className="w-5 h-5 text-primary animate-spin" />
                <span className="text-sm font-medium text-primary-dark">
                  Waiting for device...
                </span>
              </div>
            </>
          )}

          {pairingStatus === 'paired' && (
            <div className="flex flex-col items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-primary bg-opacity-10 flex items-center justify-center">
                <Check className="w-8 h-8 text-primary" />
              </div>
              <p className="text-lg font-semibold text-primary-dark">
                Device Paired Successfully!
              </p>
            </div>
          )}

          {pairingStatus === 'error' && (
            <div className="flex flex-col items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center">
                <X className="w-8 h-8 text-red-600" />
              </div>
              <div className="space-y-2">
                <p className="text-lg font-semibold text-red-600">
                  Pairing Failed
                </p>
                <p className="text-sm text-gray-600">{error}</p>
              </div>
              <button
                onClick={() => window.location.reload()}
                className="px-4 py-2 bg-primary-dark text-white rounded-lg hover:bg-primary transition-colors"
              >
                Try Again
              </button>
            </div>
          )}
        </div>

        <div className="p-6 border-t bg-gray-50 rounded-b-xl">
          <div className="flex items-start gap-3 text-sm text-gray-600">
            <div className="w-8 h-8 rounded-full bg-primary bg-opacity-10 flex items-center justify-center flex-shrink-0">
              <Smartphone className="w-4 h-4 text-primary" />
            </div>
            <p>
              Don't have the mobile app yet? Download WhatsApp DualPic from the{' '}
              <a
                href="#"
                className="text-primary hover:underline font-medium"
                onClick={(e) => e.preventDefault()}
              >
                App Store
              </a>
              {' '}or{' '}
              <a
                href="#"
                className="text-primary hover:underline font-medium"
                onClick={(e) => e.preventDefault()}
              >
                Play Store
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}