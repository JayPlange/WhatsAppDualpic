import React from 'react';
import { RouteProp } from '@react-navigation/native';
import { FrameNavigationProp } from '@nativescript/core';
import { MainStack } from '../navigation/MainStack';

export function AppContainer() {
  return (
    <MainStack />
  );
}