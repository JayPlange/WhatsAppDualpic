import React from 'react';
import { Upload, Users, Shield } from 'lucide-react';

interface ProfileUploaderProps {
  title: string;
  photo: string | null;
  setPhoto: (photo: string | null) => void;
  visibility: string;
  onVisibilityChange: (value: string) => void;
}

export function ProfileUploader({
  title,
  photo,
  setPhoto,
  visibility,
  onVisibilityChange,
}: ProfileUploaderProps) {
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="bg-white bg-opacity-90 backdrop-blur-lg rounded-xl p-5 shadow-lg slide-in">
      <h2 className="text-lg font-semibold mb-4 text-[#004D56]">{title}</h2>
      
      <div className="flex gap-4 items-center">
        <div
          className="w-24 h-24 rounded-xl border-2 border-dashed border-[#00F9B0] flex items-center justify-center cursor-pointer overflow-hidden relative photo-upload-hover group"
          onClick={() => document.getElementById(title)?.click()}
        >
          {photo ? (
            <img src={photo} alt="Profile" className="w-full h-full object-cover" />
          ) : (
            <div className="flex flex-col items-center gap-2 text-[#004D56]">
              <Upload className="w-6 h-6 group-hover:text-[#00F9B0] transition-colors" />
              <span className="text-xs">Upload</span>
            </div>
          )}
          <input
            type="file"
            id={title}
            className="hidden"
            accept="image/*"
            onChange={handleFileChange}
          />
        </div>

        <div className="flex-1">
          <label className="block text-sm font-medium text-[#004D56] mb-2 flex items-center gap-2">
            {visibility === 'everyone' ? (
              <Users className="w-4 h-4 text-[#00F9B0]" />
            ) : (
              <Shield className="w-4 h-4 text-[#00F9B0]" />
            )}
            Visibility
          </label>
          <select
            value={visibility}
            onChange={(e) => onVisibilityChange(e.target.value)}
            className="w-full p-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#00F9B0] focus:border-transparent bg-white text-[#004D56] transition-all duration-300"
          >
            <option value="everyone">Everyone</option>
            <option value="vip">Selected Contacts</option>
          </select>
        </div>
      </div>
    </div>
  );
}