import React, { useCallback } from 'react';
import { StyleSheet, View, Text, Alert } from 'react-native';
import QRCodeScanner from 'react-native-qrcode-scanner';
import { check, PERMISSIONS, request } from 'react-native-permissions';
import { usePairingStore } from '../stores/pairingStore';
import { socket } from '../services/socket';

export function QRScanner({ navigation }) {
  const setPairingCode = usePairingStore((state) => state.setPairingCode);

  const handleScan = useCallback(async ({ data }) => {
    try {
      // Validate QR code format
      if (!/^[a-zA-Z0-9]{8}$/.test(data)) {
        throw new Error('Invalid QR code format');
      }

      // Store pairing code
      setPairingCode(data);
      
      // Connect to WebSocket
      socket.connect();
      
      // Emit pairing request
      socket.emit('pair-request', { code: data });
      
      // Navigate to contacts permission screen
      navigation.navigate('ContactsPermission');
    } catch (error) {
      Alert.alert('Error', error.message);
    }
  }, [navigation, setPairingCode]);

  const checkPermission = useCallback(async () => {
    const result = await check(PERMISSIONS.IOS.CAMERA);
    
    if (result === 'denied') {
      const permissionResult = await request(PERMISSIONS.IOS.CAMERA);
      return permissionResult === 'granted';
    }
    
    return result === 'granted';
  }, []);

  return (
    <View style={styles.container}>
      <QRCodeScanner
        onRead={handleScan}
        checkPermission={checkPermission}
        topContent={
          <Text style={styles.title}>
            Scan the QR code shown in your browser extension
          </Text>
        }
        bottomContent={
          <Text style={styles.description}>
            Position the QR code within the frame to pair your device
          </Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: '#004D56',
    marginBottom: 8,
    textAlign: 'center',
    paddingHorizontal: 20,
  },
  description: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    paddingHorizontal: 40,
    marginTop: 20,
  },
});