import React, { useCallback, useState } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Contacts from 'react-native-contacts';
import { check, PERMISSIONS, request, RESULTS } from 'react-native-permissions';
import { useNavigation } from '@react-navigation/native';
import { usePairingStore } from '../stores/pairingStore';
import { socket } from '../services/socket';

export function ContactsPermission() {
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState('');
  const navigation = useNavigation();
  const pairingCode = usePairingStore((state) => state.pairingCode);

  const handleGrantPermission = useCallback(async () => {
    try {
      setLoading(true);
      setProgress('Checking permissions...');

      // Check contacts permission
      const permissionResult = await check(PERMISSIONS.IOS.CONTACTS);
      
      if (permissionResult === RESULTS.DENIED) {
        setProgress('Requesting contacts access...');
        const result = await request(PERMISSIONS.IOS.CONTACTS);
        if (result !== RESULTS.GRANTED) {
          throw new Error('Contacts permission denied');
        }
      }

      // Get contacts
      setProgress('Fetching contacts...');
      const contacts = await Contacts.getAll();
      
      // Format contacts for sync
      setProgress('Processing contacts...');
      const formattedContacts = contacts
        .filter(contact => contact.phoneNumbers && contact.phoneNumbers.length > 0)
        .map(contact => ({
          id: contact.recordID,
          name: `${contact.givenName} ${contact.familyName}`.trim(),
          phone: contact.phoneNumbers[0]?.number.replace(/[^0-9+]/g, ''),
        }));

      setProgress('Syncing with server...');
      
      // Send contacts through WebSocket
      socket.emit('sync-contacts', {
        code: pairingCode,
        contacts: formattedContacts,
      });

      // Listen for sync confirmation
      socket.on('contacts-synced', () => {
        setProgress('Sync complete!');
        navigation.navigate('PairingSuccess');
      });

      socket.on('sync-error', (error) => {
        throw new Error(error.message || 'Failed to sync contacts');
      });

    } catch (error) {
      Alert.alert('Error', error.message);
    } finally {
      setLoading(false);
    }
  }, [navigation, pairingCode]);

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <View style={styles.iconContainer}>
          <Icon name="contacts" size={64} color="#00F9B0" />
        </View>
        
        <Text style={styles.title}>Sync Your Contacts</Text>
        
        <Text style={styles.description}>
          WhatsApp DualPic needs access to your contacts to enable selective profile visibility.
          Your contacts will be encrypted and stored securely.
        </Text>

        {loading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#00F9B0" />
            <Text style={styles.progressText}>{progress}</Text>
          </View>
        ) : (
          <TouchableOpacity
            style={styles.button}
            onPress={handleGrantPermission}
          >
            <Text style={styles.buttonText}>Grant Permission</Text>
          </TouchableOpacity>
        )}

        <Text style={styles.privacy}>
          We value your privacy. Your contacts will only be used for profile visibility
          settings and won't be shared with third parties.
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  content: {
    flex: 1,
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(0, 249, 176, 0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: '#004D56',
    marginBottom: 16,
    textAlign: 'center',
  },
  description: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 32,
    lineHeight: 24,
  },
  loadingContainer: {
    alignItems: 'center',
    marginBottom: 32,
  },
  progressText: {
    marginTop: 16,
    fontSize: 14,
    color: '#004D56',
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#004D56',
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 12,
    width: '100%',
    alignItems: 'center',
    marginBottom: 24,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  privacy: {
    fontSize: 12,
    color: '#999',
    textAlign: 'center',
    lineHeight: 18,
  },
});