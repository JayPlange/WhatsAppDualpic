import { create } from 'zustand';

interface PairingState {
  pairingCode: string | null;
  setPairingCode: (code: string) => void;
  reset: () => void;
}

export const usePairingStore = create<PairingState>((set) => ({
  pairingCode: null,
  setPairingCode: (code) => set({ pairingCode: code }),
  reset: () => set({ pairingCode: null }),
}));