import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';

export function PairingSuccess() {
  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <View style={styles.iconContainer}>
          <Image 
            source={{ uri: 'https://images.unsplash.com/photo-1557683316-973673baf926' }}
            style={styles.successImage}
          />
        </View>
        
        <Text style={styles.title}>Setup Complete!</Text>
        
        <Text style={styles.description}>
          Your contacts have been synced successfully. You can now use selective visibility
          for your WhatsApp profile pictures.
        </Text>

        <Text style={styles.tip}>
          Open the WhatsApp Web extension to manage your profile pictures and visibility settings.
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  content: {
    flex: 1,
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconContainer: {
    width: 200,
    height: 200,
    marginBottom: 32,
    borderRadius: 16,
    overflow: 'hidden',
  },
  successImage: {
    width: '100%',
    height: '100%',
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#004D56',
    marginBottom: 16,
    textAlign: 'center',
  },
  description: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 24,
  },
  tip: {
    fontSize: 14,
    color: '#00F9B0',
    textAlign: 'center',
    fontWeight: '600',
  },
});