import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { QRScanner } from './src/screens/QRScanner';
import { ContactsPermission } from './src/screens/ContactsPermission';
import { PairingSuccess } from './src/screens/PairingSuccess';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator 
        initialRouteName="QRScanner"
        screenOptions={{
          headerStyle: {
            backgroundColor: '#004D56',
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontWeight: '600',
          },
        }}
      >
        <Stack.Screen 
          name="QRScanner" 
          component={QRScanner}
          options={{ title: 'Scan QR Code' }}
        />
        <Stack.Screen 
          name="ContactsPermission" 
          component={ContactsPermission}
          options={{ title: 'Contacts Access' }}
        />
        <Stack.Screen 
          name="PairingSuccess" 
          component={PairingSuccess}
          options={{ title: 'Setup Complete' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}