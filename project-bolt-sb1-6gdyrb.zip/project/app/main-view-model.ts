import { Observable } from '@nativescript/core';
import { Camera } from '@nativescript/camera';
import { Contacts } from '@nativescript/contacts';
import { io } from 'socket.io-client';

export class MainViewModel extends Observable {
  private socket: any;
  private camera: Camera;
  private contacts: Contacts;

  constructor() {
    super();
    this.camera = new Camera();
    this.contacts = new Contacts();
    this.socket = io('http://localhost:3000');
    this.setupSocketListeners();
  }

  private setupSocketListeners() {
    this.socket.on('connect', () => {
      console.log('Connected to server');
    });

    this.socket.on('contacts-synced', (data: any) => {
      console.log('Contacts synced:', data);
    });
  }

  async requestPermissions() {
    try {
      const cameraPermission = await this.camera.requestPermissions();
      const contactsPermission = await this.contacts.requestPermissions();
      return cameraPermission && contactsPermission;
    } catch (error) {
      console.error('Permission error:', error);
      return false;
    }
  }

  async scanQRCode() {
    try {
      const imageAsset = await this.camera.takePicture();
      // Process QR code from imageAsset
      return imageAsset;
    } catch (error) {
      console.error('Camera error:', error);
      return null;
    }
  }

  async getContacts() {
    try {
      const contactsList = await this.contacts.getContacts();
      return contactsList;
    } catch (error) {
      console.error('Contacts error:', error);
      return [];
    }
  }

  syncContacts(pairingCode: string, contacts: any[]) {
    this.socket.emit('sync-contacts', {
      code: pairingCode,
      contacts
    });
  }
}