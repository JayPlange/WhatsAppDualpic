import { Application } from '@nativescript/core';
import { MainViewModel } from './main-view-model';

Application.run({ create: () => new MainViewModel() });