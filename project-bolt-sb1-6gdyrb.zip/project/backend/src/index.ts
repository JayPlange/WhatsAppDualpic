import Fastify from 'fastify';
import cors from '@fastify/cors';
import websocket from '@fastify/websocket';
import Redis from 'ioredis';
import { nanoid } from 'nanoid';
import { SignJWT, jwtVerify } from 'jose';
import pino from 'pino';

// Configure logger
const logger = pino({
  transport: {
    target: 'pino-pretty',
    options: {
      colorize: true,
      translateTime: 'HH:MM:ss Z',
      ignore: 'pid,hostname'
    }
  }
});

const fastify = Fastify({ 
  logger: logger
});

const redis = new Redis(process.env.REDIS_URL);

redis.on('connect', () => {
  logger.info('Redis connected successfully');
});

redis.on('error', (err) => {
  logger.error({ err }, 'Redis connection error');
});

// JWT secret key (in production, use a proper secret management system)
const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || 'your-secret-key');

// Configure CORS
await fastify.register(cors, {
  origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'],
  credentials: true,
});

// Configure WebSocket
await fastify.register(websocket);

// Store active connections
const connections = new Map();

fastify.get('/ws', { websocket: true }, (connection, req) => {
  const clientId = nanoid();
  connections.set(clientId, connection);
  
  logger.info({ clientId }, 'New WebSocket connection established');

  connection.socket.on('message', async (message) => {
    try {
      const { type, payload } = JSON.parse(message.toString());
      logger.info({ clientId, type }, 'Received WebSocket message');

      switch (type) {
        case 'pair-request': {
          const { code } = payload;
          logger.info({ clientId, code }, 'Processing pair request');
          
          try {
            await redis.set(`pairing:${code}`, clientId, 'EX', 300); // 5 minutes expiry
            logger.info({ clientId, code }, 'Pairing code stored successfully');
          } catch (err) {
            logger.error({ err, clientId, code }, 'Failed to store pairing code');
            throw new Error('Failed to store pairing code');
          }
          break;
        }

        case 'sync-contacts': {
          const { code, contacts } = payload;
          logger.info({ clientId, code, contactCount: contacts.length }, 'Processing contact sync');
          
          try {
            // Get the extension's client ID
            const extensionClientId = await redis.get(`pairing:${code}`);
            if (!extensionClientId) {
              logger.warn({ clientId, code }, 'Invalid or expired pairing code');
              throw new Error('Invalid or expired pairing code');
            }

            // Get the extension's connection
            const extensionConnection = connections.get(extensionClientId);
            if (!extensionConnection) {
              logger.warn({ clientId, extensionClientId }, 'Extension not connected');
              throw new Error('Extension not connected');
            }

            // Generate a JWT for secure contact storage
            logger.info({ clientId }, 'Generating JWT for contacts');
            const token = await new SignJWT({ contacts })
              .setProtectedHeader({ alg: 'HS256' })
              .setIssuedAt()
              .setExpirationTime('24h')
              .sign(JWT_SECRET);

            // Store encrypted contacts
            try {
              await redis.set(`contacts:${code}`, token, 'EX', 86400); // 24 hours expiry
              logger.info({ clientId, code }, 'Contacts stored successfully');
            } catch (err) {
              logger.error({ err, clientId, code }, 'Failed to store contacts');
              throw new Error('Failed to store contacts');
            }

            // Notify extension
            extensionConnection.socket.send(JSON.stringify({
              type: 'contacts-synced',
              payload: { token },
            }));
            logger.info({ clientId, extensionClientId }, 'Extension notified of contact sync');

          } catch (error) {
            logger.error({ error, clientId, code }, 'Contact sync failed');
            connection.socket.send(JSON.stringify({
              type: 'error',
              payload: { message: error.message },
            }));
          }
          break;
        }

        case 'get-contacts': {
          const { token } = payload;
          logger.info({ clientId }, 'Processing get-contacts request');
          
          try {
            // Verify and decode JWT
            const { payload: { contacts } } = await jwtVerify(token, JWT_SECRET);
            logger.info({ clientId, contactCount: contacts.length }, 'Contacts retrieved successfully');
            
            connection.socket.send(JSON.stringify({
              type: 'contacts-data',
              payload: { contacts },
            }));
          } catch (error) {
            logger.error({ error, clientId }, 'Failed to retrieve contacts');
            connection.socket.send(JSON.stringify({
              type: 'error',
              payload: { message: 'Failed to retrieve contacts' },
            }));
          }
          break;
        }
      }
    } catch (error) {
      logger.error({ error, clientId }, 'WebSocket message processing error');
      connection.socket.send(JSON.stringify({
        type: 'error',
        payload: { message: error.message },
      }));
    }
  });

  connection.socket.on('close', () => {
    logger.info({ clientId }, 'WebSocket connection closed');
    connections.delete(clientId);
  });
});

// Start server
try {
  await fastify.listen({ port: 3000, host: '0.0.0.0' });
  logger.info('Server running on port 3000');
} catch (err) {
  fastify.log.error(err);
  process.exit(1);
}