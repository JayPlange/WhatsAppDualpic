import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve } from 'path';

export default defineConfig({
  plugins: [react()],
  build: {
    outDir: 'dist',
    rollupOptions: {
      input: {
        popup: resolve(__dirname, 'index.html'),
        background: resolve(__dirname, 'src/background.ts'),
        content: resolve(__dirname, 'src/content.ts')
      },
      output: {
        entryFileNames: (chunkInfo) => {
          if (chunkInfo.name === 'content') {
            return 'content.js';
          }
          return '[name].js';
        },
        manualChunks(id) {
          if (id.includes('content.ts')) {
            return 'content';
          }
          if (id.includes('node_modules')) {
            return 'vendor';
          }
        }
      }
    },
    sourcemap: true,
    assetsDir: '',
    emptyOutDir: true
  },
  server: {
    port: 3000,
    strictPort: true,
    hmr: {
      port: 3000,
      timeout: 120000,
      overlay: true,
      clientPort: 3000
    },
    watch: {
      usePolling: true,
      interval: 1000
    }
  }
});